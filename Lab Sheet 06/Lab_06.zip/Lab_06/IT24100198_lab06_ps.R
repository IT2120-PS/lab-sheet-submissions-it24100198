
#Exercise.
setwd("C:\\Users\\it24100198\\Desktop\\Lab_06")
getwd()


#Question_01
#i.
#---Binomial Distribution

#ii.
pbinom(46,50,0.85,lower.tail = FALSE)



#Question_02
#i.
#---count number of customer calls received in one hour.

#ii.
#---Poisson distribution

#iii.
dpois(15,12)



























